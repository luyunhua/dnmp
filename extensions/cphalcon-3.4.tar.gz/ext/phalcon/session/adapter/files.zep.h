
extern zend_class_entry *phalcon_session_adapter_files_ce;

ZEPHIR_INIT_CLASS(Phalcon_Session_Adapter_Files);

