
extern zend_class_entry *phalcon_translate_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Translate_Exception);

