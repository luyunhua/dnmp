
extern zend_class_entry *phalcon_mvc_model_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Mvc_Model_Exception);

