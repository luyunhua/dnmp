
extern zend_class_entry *phalcon_mvc_user_plugin_ce;

ZEPHIR_INIT_CLASS(Phalcon_Mvc_User_Plugin);

