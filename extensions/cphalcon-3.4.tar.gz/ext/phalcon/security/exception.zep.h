
extern zend_class_entry *phalcon_security_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Security_Exception);

