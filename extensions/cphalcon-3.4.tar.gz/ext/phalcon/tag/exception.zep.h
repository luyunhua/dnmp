
extern zend_class_entry *phalcon_tag_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Tag_Exception);

